from pathlib import Path
import base64
import io

from PIL import Image

root = Path(__file__).resolve().parents[1]

flyer = Image.open(root / "public/assets/praise-god-flyer.png").convert("RGB")
flyer.thumbnail((1100, 1100))
flyer_buffer = io.BytesIO()
flyer.save(flyer_buffer, format="JPEG", quality=78, optimize=True, progressive=True)

qr = Image.open(root / "public/assets/praise-god-qr.png").convert("RGB")
qr.thumbnail((900, 900))
qr_buffer = io.BytesIO()
qr.save(qr_buffer, format="PNG", optimize=True)

out = (
    "export const ASSETS = {\n"
    f'  flyer: "data:image/jpeg;base64,{base64.b64encode(flyer_buffer.getvalue()).decode()}",\n'
    f'  qr: "data:image/png;base64,{base64.b64encode(qr_buffer.getvalue()).decode()}"\n'
    "};\n"
)

(root / "src/assets.js").write_text(out, encoding="utf-8")
print(len(flyer_buffer.getvalue()), len(qr_buffer.getvalue()), len(out))
